package com.everbank.commission.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.UUID;

@Data
public class PaymentRequestDTO {
    private UUID policyId;
    private BigDecimal amount;
}
