package com.everbank.commission.controller;

import com.everbank.commission.dto.PaymentRequestDTO;
import com.everbank.commission.entity.PremiumPayment;
import com.everbank.commission.service.PremiumPaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PremiumPaymentService paymentService;

    @PostMapping
    public ResponseEntity<PremiumPayment> processPayment(@RequestBody PaymentRequestDTO request) {
        PremiumPayment payment = paymentService.processPayment(request);
        return ResponseEntity.ok(payment);
    }
}
