package com.everbank.commission.service;

import com.everbank.commission.dto.PaymentRequestDTO;
import com.everbank.commission.entity.Policy;
import com.everbank.commission.entity.PremiumPayment;
import com.everbank.commission.entity.enums.PaymentStatus;
import com.everbank.commission.repository.PolicyRepository;
import com.everbank.commission.repository.PremiumPaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class PremiumPaymentService {
    private final PremiumPaymentRepository paymentRepository;
    private final PolicyRepository policyRepository;
    private final CommissionService commissionService;

    @Transactional
    public PremiumPayment processPayment(PaymentRequestDTO requestDto) {
        Policy policy = policyRepository.findById(requestDto.getPolicyId())
                .orElseThrow(() -> new IllegalArgumentException("Policy not found"));

        PremiumPayment payment = PremiumPayment.builder()
                .policy(policy)
                .amount(requestDto.getAmount())
                .paymentDate(LocalDateTime.now())
                .status(PaymentStatus.SUCCESS)
                .build();

        payment = paymentRepository.save(payment);

        // Trigger commission calculation upon successful payment
        commissionService.calculateAndSaveCommission(policy, payment.getAmount());

        return payment;
    }
}
