package com.everbank.commission.service;

import com.everbank.commission.entity.Commission;
import com.everbank.commission.entity.Policy;
import com.everbank.commission.entity.enums.CommissionStatus;
import com.everbank.commission.repository.CommissionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class CommissionService {
    private final CommissionRepository commissionRepository;

    @Transactional
    public Commission calculateAndSaveCommission(Policy policy, BigDecimal paymentAmount) {
        BigDecimal rate = policy.getAgent().getCommissionRate();
        BigDecimal commissionAmount = paymentAmount.multiply(rate);

        Commission commission = Commission.builder()
                .policy(policy)
                .agent(policy.getAgent())
                .amount(commissionAmount)
                .calculationDate(LocalDateTime.now())
                .status(CommissionStatus.UNPAID)
                .build();

        return commissionRepository.save(commission);
    }
}
