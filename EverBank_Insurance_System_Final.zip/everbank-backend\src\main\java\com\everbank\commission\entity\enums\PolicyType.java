package com.everbank.commission.entity.enums;

public enum PolicyType {
    LIFE, HEALTH, AUTO, HOME
}
