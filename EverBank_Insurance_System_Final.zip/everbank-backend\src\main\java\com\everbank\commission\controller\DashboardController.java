package com.everbank.commission.controller;

import com.everbank.commission.repository.CommissionRepository;
import com.everbank.commission.repository.PolicyRepository;
import com.everbank.commission.repository.PremiumPaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final CommissionRepository commissionRepository;
    private final PolicyRepository policyRepository;
    private final PremiumPaymentRepository paymentRepository;

    @GetMapping("/metrics")
    public ResponseEntity<Map<String, Object>> getMetrics() {
        Map<String, Object> metrics = new HashMap<>();

        BigDecimal totalCommissions = commissionRepository.findAll().stream()
                .map(c -> c.getAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        long activePolicies = policyRepository.count();
        long totalPayments = paymentRepository.count();

        metrics.put("totalCommissions", totalCommissions);
        metrics.put("activePolicies", activePolicies);
        metrics.put("pendingPayments", totalPayments == 0 ? 0 : 5); // Mock logic for pending
        metrics.put("growthRate", "+12.5%"); // Mock logic for growth

        return ResponseEntity.ok(metrics);
    }
}
