package com.everbank.commission.service;

import com.everbank.commission.entity.Agent;
import com.everbank.commission.entity.Commission;
import com.everbank.commission.entity.Policy;
import com.everbank.commission.entity.enums.CommissionStatus;
import com.everbank.commission.repository.CommissionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CommissionServiceTest {

    @Mock
    private CommissionRepository commissionRepository;

    @InjectMocks
    private CommissionService commissionService;

    private Policy policy;
    private Agent agent;

    @BeforeEach
    void setUp() {
        agent = Agent.builder()
                .commissionRate(new BigDecimal("0.05")) // 5% commission
                .build();

        policy = Policy.builder()
                .agent(agent)
                .build();
    }

    @Test
    void calculateAndSaveCommission() {
        // Arrange
        BigDecimal paymentAmount = new BigDecimal("1000.00");
        when(commissionRepository.save(any(Commission.class))).thenAnswer(i -> i.getArguments()[0]);

        // Act
        Commission result = commissionService.calculateAndSaveCommission(policy, paymentAmount);

        // Assert
        assertNotNull(result);
        assertEquals(new BigDecimal("50.0000"), result.getAmount());
        assertEquals(CommissionStatus.UNPAID, result.getStatus());
        assertEquals(agent, result.getAgent());
        assertEquals(policy, result.getPolicy());
    }
}
