package com.everbank.commission.config;

import com.everbank.commission.entity.Agent;
import com.everbank.commission.entity.Customer;
import com.everbank.commission.repository.AgentRepository;
import com.everbank.commission.repository.CustomerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class DataSeeder {

    @Bean
    public CommandLineRunner seedData(AgentRepository agentRepository, CustomerRepository customerRepository) {
        return args -> {
            if (agentRepository.count() == 0) {
                Agent agent = Agent.builder()
                        .name("Alice Smith")
                        .email("alice.smith@everbank.com")
                        .commissionRate(new BigDecimal("0.05"))
                        .level(1)
                        .build();
                agentRepository.save(agent);
                System.out.println("Seeded Agent: " + agent.getId());
            }

            if (customerRepository.count() == 0) {
                Customer customer = Customer.builder()
                        .name("John Doe")
                        .email("john.doe@gmail.com")
                        .phone("123-456-7890")
                        .address("123 Main St, Anytown, USA")
                        .build();
                customerRepository.save(customer);
                System.out.println("Seeded Customer: " + customer.getId());
            }
        };
    }
}
