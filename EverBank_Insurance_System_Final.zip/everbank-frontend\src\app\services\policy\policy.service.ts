import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PolicyRequestDTO {
  policyNumber: string;
  type: string;
  premiumAmount: number;
  startDate: string;
  endDate: string;
  agentId: string;
  customerId: string;
}

export interface Policy {
  id: string;
  policyNumber: string;
  type: string;
  premiumAmount: number;
  startDate: string;
  endDate: string;
  status: string;
  agent: any;
  customer: any;
}

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private apiUrl = 'http://localhost:8080/api/policies';

  constructor(private http: HttpClient) { }

  createPolicy(policyData: PolicyRequestDTO): Observable<Policy> {
    return this.http.post<Policy>(this.apiUrl, policyData);
  }
}
