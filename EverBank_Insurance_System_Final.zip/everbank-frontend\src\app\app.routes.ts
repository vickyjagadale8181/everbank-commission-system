import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PolicyManagementComponent } from './components/policy-management/policy-management.component';
import { CommissionTrackingComponent } from './components/commission-tracking/commission-tracking.component';

export const routes: Routes = [
    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
    { path: 'dashboard', component: DashboardComponent },
    { path: 'policies', component: PolicyManagementComponent },
    { path: 'commissions', component: CommissionTrackingComponent }
];
