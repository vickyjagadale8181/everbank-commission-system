import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Commission {
  id: string;
  policy: any;
  agent: any;
  amount: number;
  calculationDate: string;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class CommissionService {
  private apiUrl = 'http://localhost:8080/api/commissions';

  constructor(private http: HttpClient) { }

  getCommissions(): Observable<Commission[]> {
    return this.http.get<Commission[]>(this.apiUrl);
  }

  settleCommission(id: string): Observable<Commission> {
    return this.http.post<Commission>(`${this.apiUrl}/${id}/settle`, {});
  }
}
