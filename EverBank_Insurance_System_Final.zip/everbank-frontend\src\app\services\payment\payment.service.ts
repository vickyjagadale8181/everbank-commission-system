import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PaymentRequestDTO {
  policyId: string;
  amount: number;
}

export interface PremiumPayment {
  id: string;
  policyDetails: any;
  amount: number;
  paymentDate: string;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private apiUrl = 'http://localhost:8080/api/payments';

  constructor(private http: HttpClient) { }

  processPayment(paymentData: PaymentRequestDTO): Observable<PremiumPayment> {
    return this.http.post<PremiumPayment>(this.apiUrl, paymentData);
  }
}
