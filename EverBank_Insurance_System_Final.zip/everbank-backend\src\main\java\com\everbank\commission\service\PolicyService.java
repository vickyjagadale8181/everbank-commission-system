package com.everbank.commission.service;

import com.everbank.commission.dto.PolicyRequestDTO;
import com.everbank.commission.entity.Agent;
import com.everbank.commission.entity.Customer;
import com.everbank.commission.entity.Policy;
import com.everbank.commission.entity.enums.PolicyStatus;
import com.everbank.commission.repository.AgentRepository;
import com.everbank.commission.repository.CustomerRepository;
import com.everbank.commission.repository.PolicyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PolicyService {
    private final PolicyRepository policyRepository;
    private final AgentRepository agentRepository;
    private final CustomerRepository customerRepository;

    @Transactional
    public Policy createPolicy(PolicyRequestDTO dto) {
        Agent agent = agentRepository.findById(dto.getAgentId())
                .orElseThrow(() -> new IllegalArgumentException("Agent not found"));
        Customer customer = customerRepository.findById(dto.getCustomerId())
                .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

        Policy policy = Policy.builder()
                .policyNumber(dto.getPolicyNumber())
                .type(dto.getType())
                .premiumAmount(dto.getPremiumAmount())
                .startDate(dto.getStartDate())
                .endDate(dto.getEndDate())
                .status(PolicyStatus.ACTIVE)
                .agent(agent)
                .customer(customer)
                .build();

        return policyRepository.save(policy);
    }
}
