package com.everbank.commission;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EverBankCommissionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EverBankCommissionSystemApplication.class, args);
	}

}
