package com.everbank.commission.entity.enums;

public enum PolicyStatus {
    ACTIVE, EXPIRED, CANCELLED
}
