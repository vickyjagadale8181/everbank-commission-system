package com.everbank.commission.repository;

import com.everbank.commission.entity.PremiumPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface PremiumPaymentRepository extends JpaRepository<PremiumPayment, UUID> {
}
