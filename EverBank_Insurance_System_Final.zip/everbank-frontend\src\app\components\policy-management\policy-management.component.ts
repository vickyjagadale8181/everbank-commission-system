import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PolicyService, PolicyRequestDTO } from '../../services/policy/policy.service';
import { AgentService, Agent } from '../../services/agent/agent.service';
import { CustomerService, Customer } from '../../services/customer/customer.service';

@Component({
  selector: 'app-policy-management',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './policy-management.component.html',
  styleUrl: './policy-management.component.css'
})
export class PolicyManagementComponent implements OnInit {
  policyRequest: PolicyRequestDTO = {
    policyNumber: '',
    type: 'LIFE',
    premiumAmount: 0,
    startDate: '',
    endDate: '',
    agentId: '',
    customerId: ''
  };

  agents: Agent[] = [];
  customers: Customer[] = [];

  constructor(
    private policyService: PolicyService,
    private agentService: AgentService,
    private customerService: CustomerService
  ) { }

  ngOnInit() {
    this.agentService.getAgents().subscribe(data => this.agents = data);
    this.customerService.getCustomers().subscribe(data => this.customers = data);
  }

  submitPolicy() {
    this.policyService.createPolicy(this.policyRequest).subscribe({
      next: (res) => {
        alert('Policy created successfully!');
        this.resetForm();
      },
      error: (err) => {
        console.error('Error creating policy', err);
        alert('Failed to create policy. Ensure backend is running.');
      }
    });
  }

  private resetForm() {
    this.policyRequest = {
      policyNumber: '',
      type: 'LIFE',
      premiumAmount: 0,
      startDate: '',
      endDate: '',
      agentId: '',
      customerId: ''
    };
  }
}
