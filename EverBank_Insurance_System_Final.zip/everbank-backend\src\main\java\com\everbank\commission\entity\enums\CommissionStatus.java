package com.everbank.commission.entity.enums;

public enum CommissionStatus {
    UNPAID, PAID
}
