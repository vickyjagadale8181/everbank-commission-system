import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { CommissionService, Commission } from '../../services/commission/commission.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  metrics = {
    totalCommissions: 0,
    activePolicies: 0,
    pendingPayments: 0,
    growthRate: '0%'
  };

  recentActivity: any[] = [];

  constructor(private http: HttpClient, private commissionService: CommissionService) { }

  ngOnInit() {
    this.fetchMetrics();
    this.fetchRecentActivity();
  }

  fetchMetrics() {
    this.http.get<any>('http://localhost:8080/api/dashboard/metrics').subscribe({
      next: (data) => this.metrics = data,
      error: (err) => console.error('Error fetching metrics', err)
    });
  }

  fetchRecentActivity() {
    this.commissionService.getCommissions().subscribe({
      next: (data) => {
        this.recentActivity = data.slice(0, 5).map(c => ({
          type: 'Commission ' + c.status,
          amount: c.amount,
          agent: c.agent?.name,
          date: c.calculationDate,
          status: c.status
        }));
      },
      error: (err) => console.error('Error fetching activity', err)
    });
  }
}
