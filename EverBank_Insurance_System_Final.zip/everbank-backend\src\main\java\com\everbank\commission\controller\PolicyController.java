package com.everbank.commission.controller;

import com.everbank.commission.dto.PolicyRequestDTO;
import com.everbank.commission.entity.Policy;
import com.everbank.commission.service.PolicyService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/policies")
@RequiredArgsConstructor
public class PolicyController {

    private final PolicyService policyService;

    @PostMapping
    public ResponseEntity<Policy> createPolicy(@RequestBody PolicyRequestDTO request) {
        Policy policy = policyService.createPolicy(request);
        return ResponseEntity.ok(policy);
    }
}
