package com.everbank.commission.dto;

import com.everbank.commission.entity.enums.PolicyType;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Data
public class PolicyRequestDTO {
    private String policyNumber;
    private PolicyType type;
    private BigDecimal premiumAmount;
    private LocalDate startDate;
    private LocalDate endDate;
    private UUID agentId;
    private UUID customerId;
}
