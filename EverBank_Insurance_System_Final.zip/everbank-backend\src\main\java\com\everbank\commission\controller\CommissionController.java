package com.everbank.commission.controller;

import com.everbank.commission.entity.Commission;
import com.everbank.commission.entity.enums.CommissionStatus;
import com.everbank.commission.repository.CommissionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/commissions")
@RequiredArgsConstructor
public class CommissionController {

    private final CommissionRepository commissionRepository;

    @GetMapping
    public ResponseEntity<List<Commission>> getAllCommissions() {
        return ResponseEntity.ok(commissionRepository.findAll());
    }

    @PostMapping("/{id}/settle")
    public ResponseEntity<Commission> settleCommission(@PathVariable UUID id) {
        Commission commission = commissionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Commission not found"));
        commission.setStatus(CommissionStatus.PAID);
        return ResponseEntity.ok(commissionRepository.save(commission));
    }
}
