import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommissionService, Commission } from '../../services/commission/commission.service';

@Component({
  selector: 'app-commission-tracking',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './commission-tracking.component.html',
  styleUrl: './commission-tracking.component.css'
})
export class CommissionTrackingComponent implements OnInit {
  commissions: Commission[] = [];

  constructor(private commissionService: CommissionService) { }

  ngOnInit() {
    this.loadCommissions();
  }

  loadCommissions() {
    this.commissionService.getCommissions().subscribe(data => this.commissions = data);
  }

  markAsPaid(commission: Commission) {
    this.commissionService.settleCommission(commission.id).subscribe({
      next: (res) => {
        commission.status = 'PAID';
      },
      error: (err) => {
        console.error('Error settling commission', err);
        alert('Failed to settle commission. Backend error.');
      }
    });
  }
}
