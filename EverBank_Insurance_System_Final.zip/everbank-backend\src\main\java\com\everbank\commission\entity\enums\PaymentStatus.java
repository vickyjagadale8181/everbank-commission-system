package com.everbank.commission.entity.enums;

public enum PaymentStatus {
    SUCCESS, PENDING, FAILED
}
